# Evidence — FL-07

The assignment requires a raw, unedited screen capture of a successful end-to-end run. Do not manufacture screenshots in the repository.

Capture:

1. MCP server/tool connection visible.
2. The single new-input request.
3. At least one real MCP tool call and returned data.
4. Continued agent execution without manual hand-editing.
5. Final source-grounded study notes.

Recommended file names:

- `mcp-connected.png`
- `raw-run-01.mp4`
- `run-notes.md`

## Evidence statement

> Evidence in this folder is added after the live run. Placeholder files are not presented as proof of execution.
