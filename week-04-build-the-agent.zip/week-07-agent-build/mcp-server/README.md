# Local MCP Server

This server gives the selected MCP client three read-only tools:

- `list_project_files`
- `read_project_file`
- `search_project`

## Windows setup

From this `mcp-server` folder:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Test the Python file:

```powershell
python server.py
```

The process waits for MCP stdio input. Stop it with `Ctrl+C`.

## Claude Desktop configuration

Add a server entry to Claude Desktop's MCP configuration. Use absolute Windows paths for both Python and `server.py`.

Example shape:

```json
{
  "mcpServers": {
    "flyrank-week7": {
      "command": "C:\\Path\\To\\Python\\python.exe",
      "args": ["C:\\Path\\To\\week-07-agent-build\\mcp-server\\server.py"],
      "env": {
        "FLRANK_WORKSPACE": "C:\\Path\\To\\week-07-agent-build"
      }
    }
  }
}
```

Replace the paths with the actual paths on the user's machine. Restart the MCP client after saving configuration.

## Security boundary

The server only exposes read operations and rejects paths outside the configured workspace. It does not execute shell commands, delete files, or write files.
