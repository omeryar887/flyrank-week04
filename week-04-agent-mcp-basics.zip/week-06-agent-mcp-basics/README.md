# Week 6: Agent Concepts and MCP Basics

## Phase
Build (core)

## Estimated effort
5 hours

## One-line claim
I build practical software systems that turn real requirements into usable web, mobile, and backend solutions.

## What this week proves
This week moves from a fixed AI workflow into the ideas behind agentic systems and tool-connected AI. The work distinguishes a predictable workflow from an agent, explains MCP's core primitives, and provides a small local MCP server that can be connected to an MCP client such as Claude Desktop.

## FL-04 classification
The Week 5 **Source-Grounded Technical Study Notes** pipeline is a **workflow**, not an agent. Its stages are fixed: Gather → Synthesize → Draft → Review & format. The next stage is selected by the workflow design rather than by the model deciding its own process.

## MCP build
This package includes a small Python MCP server with:
- tools to list files, read a file, and search files;
- a read-only resource exposing the FL-04 workflow description;
- a reusable prompt for reviewing a workflow evidence file.

The server is intentionally read-only. It demonstrates the MCP connection without giving an AI unrestricted write or destructive access to the computer.

## Evidence status
The server code and three task plans are ready. The actual Claude/MCP screenshots must be captured on the user's machine after connecting the server. They are not fabricated in this package.

## Folder structure

```text
week-06-agent-mcp-basics/
├── README.md
├── explainer.md
├── workflow-vs-agent.md
├── mcp-primitives.md
├── agent-upgrade.md
├── mcp-setup-guide.md
├── evidence-checklist.md
├── walkthrough.md
├── mcp-server/
│   ├── server.py
│   ├── requirements.txt
│   └── README.md
├── tasks/
│   ├── task-01-list-workflow-files.md
│   ├── task-02-read-claude-config.md
│   └── task-03-search-failure-points.md
├── evidence/
│   ├── screenshot-01-placeholder.md
│   ├── screenshot-02-placeholder.md
│   └── screenshot-03-placeholder.md
└── references/
    └── source-notes.md
```

## Pass/revise checklist

- [x] Workflow vs agent distinction explained.
- [x] FL-04 classified as a workflow with reasons.
- [x] MCP tools/resources/prompts explained.
- [x] Working local MCP server implementation included.
- [x] Three tool-call tasks designed.
- [x] One concrete agent upgrade identified.
- [ ] Actual MCP connection completed in an MCP client.
- [ ] Three screenshots captured showing tool calls and results.

## Source basis
The conceptual explanations are grounded in Anthropic's *Building Effective Agents* and the official Model Context Protocol documentation. The source notes are recorded in `references/source-notes.md`.
