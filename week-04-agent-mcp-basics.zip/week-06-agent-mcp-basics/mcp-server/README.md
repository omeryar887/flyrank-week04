# Local MCP Server

A small read-only MCP server for the Week 6 assignment.

## Run locally

```powershell
py -m pip install -r requirements.txt
py server.py
```

The server uses stdio transport so an MCP client can launch it as a local process.

## Exposed capabilities

### Tools
- `list_files`
- `read_file`
- `search_files`

### Resource
- `workflow://fl-04`

### Prompt
- `review_workflow_file`

The server limits file access to the Week 6 project directory and rejects path traversal outside that directory.
